import arpa

models = arpa.loadf('train.lm')

lm = models[0]
# 词汇表
print(lm.vocabulary())
# 各个ngrams统计数据
print(lm.counts())
# 最高阶数
print(lm.order())

print(lm.p('中国 人民'))
print(lm.p('国家 主席 江 泽民'))
print(lm.s('以 江 泽民 同志 为 核心 的 党中央'))

print(lm.log_s('秦皇 战车 碾 过 的 大道 旁'))
print(lm.log_s('<unk> 战车 碾 过 的 大道 旁'))