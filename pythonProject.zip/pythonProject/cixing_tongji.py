import csv

cixing_file = open("renmincixing.csv", "r")
cixing_reader = csv.reader(cixing_file)
sents = []
for item in cixing_reader:
    sent = []
    for i in item:
        sent.append(i.strip())
    sents.append(sent)

# print(sents)

part = dict()
# 统计所有词性个数
for sent in sents:
    for word in sent:
        word_part = word.split('/')[-1].split(']')[0].split('!')[0]
        if word_part in part:
            part[word_part] += 1
        else:
            part[word_part] = 1

part_len = len(part)
print(part, "一共多少类：", part_len)
print("总频次", sum(part.values()))

# 或得转移矩阵
trans = dict()
for sent in sents:
    for i in range(len(sent) - 1):
        one = sent[i].split('/')[-1].split(']')[0].split('!')[0]
        two = sent[i + 1].split('/')[-1].split(']')[0].split('!')[0]
        if one in trans:
            if two in trans[one]:
                trans[one][two] += 1
            else:
                trans[one][two] = 1
        else:
            trans[one] = dict()
            trans[one][two] = 1
print(trans)

# 每个词的词性概率
percent = dict()
for sent in sents:
    for word in sent:
        word_word = word.split('/')[0].split('{')[0].strip('[')
        word_part = word.split('/')[-1].split(']')[0].split('!')[0]
        if word_word in percent:
            if word_part in percent[word_word]:
                percent[word_word][word_part] += 1
            else:
                percent[word_word][word_part] = 1
        else:
            percent[word_word] = dict()
            percent[word_word][word_part] = 1
# print(percent)

text = ['他', '的', '希望', '是', '希望', '上学']
text_percent = []

# 这里我们假设是所有单词都已经人民日报语料库了
for word in text:
    word_percent = percent[word]
    text_percent.append(word_percent)
print(text_percent)

# 下面我们来使用Viterbi算法计算出最佳的组成
dis = [dict() for _ in range(len(text))]
node = [dict() for _ in range(len(text))]
for first in text_percent[0].keys():
    dis[0][first] = 1
for i in range(len(text) - 1):
    word_one = text[i]
    word_two = text[i + 1]
    word_one_percent_dict = text_percent[i]
    word_two_percent_dict = text_percent[i + 1]

    word_one_percent_key = list(word_one_percent_dict.keys())
    word_one_percent_value = list(word_one_percent_dict.values())
    word_two_percent_key = list(word_two_percent_dict.keys())
    word_two_percent_value = list(word_two_percent_dict.values())
    for word_two_per in word_two_percent_key:
        tmp_dis = []
        for word_one_per in word_one_percent_key:
            if word_two_per in trans[word_one_per]:
                tmp_num = dis[i][word_one_per] * (
                        (trans[word_one_per][word_two_per] + 1) / (part[word_one_per] + part_len)) * (
                                  text_percent[i + 1][word_two_per] / part[word_two_per])
                tmp_dis.append(tmp_num)
            else:
                tmp_num = dis[i][word_one_per] * (1 / (part[word_one_per] + part_len)) * (
                        text_percent[i + 1][word_two_per] / part[word_two_per])
                tmp_dis.append(tmp_num)

        max_tmp_dis = max(tmp_dis)
        max_tmp_dis_loc = tmp_dis.index(max_tmp_dis)
        dis[i + 1][word_two_per] = max_tmp_dis
        node[i + 1][word_two_per] = word_one_percent_key[max_tmp_dis_loc]
print(dis, node)

# 根据node来倒找答案
path = []
f_value = list(dis[len(dis)-1].values())
f_key = list(dis[len(dis)-1].keys())
f = f_key[f_value.index(max(f_value))]

path.append(f)
for i in range(len(dis)-1,0,-1):
    f = node[i][f]
    path.append(f)
path.reverse()
print(path)